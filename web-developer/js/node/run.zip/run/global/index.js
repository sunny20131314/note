console.log('🚀 ~ file: index.js ~ line 2 ~ __filename', __filename);
console.log('🚀 ~ file: index.js ~ line 3 ~ __dirname', __dirname);
