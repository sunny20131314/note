// note: require拿到的是 module.exports 的所有内容
// es6: import AAA: AAA是 default 对应的变量
// es6: import * as AAA: AAA 拿到的是 export 的所有变量集
const { counter } = require('./b');

console.log(
  "🚀 ~ file: a.js ~ line 6 ~ counter(['js', 'nodejs', 'react'])",
  counter(['js', 'nodejs', 'react'])
);
