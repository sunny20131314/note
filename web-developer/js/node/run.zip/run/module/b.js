var counter = (arr) => {
  return arr.length;
};
module.exports = { counter };
