const fs = require('fs');
const path = require('path');

const { dirPath, articlePath, articleCopyPath } = require('./constants/path');
const { encrypt, decrypt } = require('./utils');

// 压缩
const zlib = require('zlib');

// const pwd = Buffer.from(process.env.PASS || 'password');
// const encryptStream = crypto.createCipheriv('aes-256-cbc', pwd);

// const gzip = zlib.createGzip();

let key = '123456789abcdefg';
console.log('加密的key:', key);
let iv = 'abcdefg123456789';
console.log('加密的iv:', iv);
let data = 'This is an example';
console.log('需要加密的数据:', data);
let crypted = encrypt(key, iv, data);
console.log('数据加密后:', crypted);
let dec = decrypt(key, iv, crypted);
console.log('数据解密后:', dec);

// const readStream = fs.createReadStream(articlePath);
// fs.mkdir(dirPath, { recursive: true }, function () {
//   const writeStream = fs.createWriteStream(articleCopyPath);

//   readStream
//     .pipe(encryptStream)
//     .pipe(gzip)
//     .pipe(writeStream)
//     .on('finish', function (err, data) {
//       console.log('🚀 ~ file: file.js ~ line 46 ~ err, data', err, data);

//       require('./utils').removeDirFile(articleCopyPath, dirPath);
//     });
// });
